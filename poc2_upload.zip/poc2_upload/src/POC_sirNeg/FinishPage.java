package POC_sirNeg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class FinishPage {
	WebDriver dr;
	By cart_item;
	String base_xp="//div[@class=\"cart_item\"][";
	public FinishPage(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr,this);
	
	}
	public String cart(int n)
	{
			
		cart_item=By.xpath(base_xp+n+"]//div[@class='inventory_item_name']");
		String name=dr.findElement(cart_item).getText();
		return name;
		 
	}

}
