package POC_sirNeg;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_rw {
	
	public static String fiLename1 ="C:\\Users\\kanika.chaudhary\\Documents\\selenium.xlsx";
	public static Object[][] td; 
	public static int rowno,colno;
	
	public static void read_excel(int n)
	
	{
		//td = new Object[2][1]; 
		try {
		
		 System.out.println(" in get test data row " + rowno);
		 File f = new File(fiLename1); 
		 
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis); 
		XSSFSheet sheet = wb.getSheet("POC");
		XSSFRow row = sheet.getRow(n);
		XSSFCell cell1 = row.getCell(0); 
		System.out.println(" in readexcel 1 : " + cell1.getStringCellValue());
		
		td[rowno-1][0] = cell1.getStringCellValue(); 

		System.out.println(" in readexcel 2 : " + td[rowno-1][0]);
		 }
		 catch (Exception e) { 
			 System.out.println(e); } 
	}
}

