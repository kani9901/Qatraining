package POC_sirNeg;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class HomePage {
				
		WebDriver dr;
		String base_xp="//div[@class='inventory_item'][";
		By xname,xprice,xbtn;
		excel_rw rw=new excel_rw();
		static ArrayList<product> ap;
		static ArrayList<product> pp=new ArrayList<product>();;
		
		
		public HomePage(WebDriver dr)
		{
			this.dr=dr;
			PageFactory.initElements(dr,this);
		}
		
		public String get_prod_name(int n)
		{
			xname=By.xpath(base_xp+n+"]//div[@class='inventory_item_name']");
			String pname=dr.findElement(xname).getText();
			return pname;
		}
		public String get_prod_price(int n)
		{
			xname=By.xpath(base_xp+n+"]//div[@class='inventory_item_price']");
			String pprice=dr.findElement(xprice).getText();
			return pprice;
		}
		public void add_to_cart(int n)
		{
			xbtn=By.xpath(base_xp+n+"]//button");
			dr.findElement(xbtn).click();	
		}
		public void click_cart()
		{
			dr.findElement(By.xpath("//div[@class='shopping_cart_container']")).click();
			
		}
		public void al_product()
		{
			ap=new ArrayList<product>();
			product p1=new product("Sauce Labs Backpack","29.99",1);
			product p2=new product("Sauce Labs Bike Light","29.99",2);
			product p3=new product("Sauce Labs Bolt T-Shirt","29.99",3);
			product p4=new product("Sauce Labs Fleece Jacket","29.99",4);
			product p5=new product("Sauce Labs Onesie","29.99",5);
			product p6=new product("Test.allTheThings() T-Shirt (Red)","29.99",6);
			
			ap.add(p1);
			ap.add(p2);
			ap.add(p3);
			ap.add(p4);
			ap.add(p5);
			ap.add(p6);
			
		}
		public int search_prod(String str)
		{
			System.out.println(str+"  home page");
			int cart=0;
			int productadd=-1;
			al_product();
			for(product pp:ap)
			{
				if(pp.pname.equals(str))
				{
					System.out.println("find");
					cart=pp.xpath;
					productadd=0;
					break;
				}
				else
				{
					cart=8;
					System.out.println("item not found: try again");
				}
			}
			return cart;
			
		}
	}

