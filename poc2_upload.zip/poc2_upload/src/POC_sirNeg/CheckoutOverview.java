package POC_sirNeg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

public class CheckoutOverview {
	
	static WebDriver dr;
	static By ItemTotal=By.xpath("//div[@class=\"summary_subtotal_label\"]");
	static By tax1=By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[6]");
	static By totalamount=By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[7]");
	
	static By lname=By.xpath("//*[@id=\"last-name\"]");
	static By pcode=By.xpath("//*[@id=\"postal-code\"]");
	static By checkoutbtn=By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[8]/a[2]");
	static By cartbtncancel=By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[2]/a");
	//*[@id="checkout_summary_container"]/div/div[2]/div[8]/a[2]
	//*[@id="checkout_summary_container"]/div/div[2]/div[8]/a[2]
	public CheckoutOverview(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	public String get_Title()
	{
		String str=dr.findElement(By.xpath("//*[@id=\"contents_wrapper\"]/div[2]")).getText();
		return str;
	}
	public void cartbtnfinishClick()
	{
		dr.findElement(checkoutbtn).click();
	}
	public void cartbtncancelClick()
	{
		dr.findElement(cartbtncancel).click();
	}
	public float get_ItemTotal()
	{
		String itemTotalstr=dr.findElement(ItemTotal).getText();
		float itemTotalstr1=calculate(itemTotalstr);
		return itemTotalstr1;
	}
	public float get_ItemTax()
	{
		String tax=dr.findElement(tax1).getText();
		float tax1=calculate(tax);
		return tax1;
	}
	public float get_Total()
	{
		String Totalstr=dr.findElement(totalamount).getText();
		float Totalstr1=calculate(Totalstr);
		return Totalstr1;
	}
	public float calculate(String sl)
	{
		 int firstIndex = sl.indexOf('$'); 
			 String str1=sl.substring(firstIndex+1,sl.length());
			 float amt=Float.parseFloat(str1);
			 return amt;
	 } 
	/**public  float verifyTotalValue()
	{
		float f1=get_ItemTotal();
		float f2=get_ItemTax();
		float f3=get_ItemTotal();
		float sum=f1+f2;
		System.out.println("Total actual value is:"+sum);
		
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(sum, f3);
		sa.assertAll();
		
		return sum;
					
	}**/
	
}
