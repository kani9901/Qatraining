package POC_sirNeg;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class testrunner extends excel_rw{
	
	WebDriver dr;
	login_page lp;
	HomePage hp;
	CartPage cp;
	CheckoutPage chp;
	CheckoutOverview chow;
	WebDriverWait wait;
	static int a=1;
	String autURL,nodeURL;
	
	@BeforeClass
	public void a() throws MalformedURLException
	{
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr=new ChromeDriver();
		dr.get("http://www.saucedemo.com");
		
		/**autURL="http://www.saucedemo.com";
		nodeURL="http://172.16.128.38:5566/wd/hub";
		DesiredCapabilities cap=DesiredCapabilities.chrome();
		cap.setBrowserName("chrome");
		cap.setPlatform(Platform.WINDOWS);
		
		dr=new RemoteWebDriver(new URL(nodeURL),cap);**/
		lp=new login_page(dr);
		hp=new HomePage(dr);
		cp=new CartPage(dr);
		chp=new CheckoutPage(dr);
		chow=new CheckoutOverview(dr);
		lp.do_login("standard_user", "secret_sauce");
		 wait = new WebDriverWait(dr,20);
	 
		 td = new Object[2][1];
		for(rowno=1;rowno<=2;rowno++)
			{
				read_excel(rowno);
				System.out.println(" rowno : " + rowno + " testdata  :"+td[rowno-1][0]);
			}
		
	}
	@Test
	public void b()
	{
		String str=dr.findElement(By.xpath("//div[@class=\"product_label\"]")).getText();
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(str, "Products");
		sa.assertAll();
	}
	
	
	 @Test(dataProvider="security")
	public void c(String data)
	{
		 System.out.println("data=="+data);
		 int i=hp.search_prod(data);
		 System.out.println("data=="+data+""+"cart"+i);
		 if(i!=8) 
		 {
		hp.add_to_cart(i);
		 wait = new WebDriverWait(dr,20);
		String e_pn1=hp.get_prod_name(i);
		
		
		hp.click_cart();
		 wait = new WebDriverWait(dr,20);
	
		String a_pn1=cp.cartItemName(a++);
		System.out.println(a_pn1+"            is in cart");
		wait= new WebDriverWait(dr,2);
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(a_pn1,e_pn1);	
		System.out.println("item added to cart is     "+ e_pn1+"item found in cart is            "+a_pn1);

		log_file.log(a_pn1,e_pn1);
		cp.clickContinue();
		sa.assertAll();
		}
					
	}
	@DataProvider(name="security")
	 public Object[][] getdata() {
		
	return td;
	}
				 
		
	@Test
	public void d()
	{
		dr.get("https://www.saucedemo.com/checkout-step-one.html");
		chp.details("kanika","chaudhary","325120");
				
		String a_pn1=chow.get_Title();
		System.out.println(a_pn1);
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(a_pn1,"Checkout: Overview");	
		sa.assertAll();
	
	}
	@Test
	public void e()
	{
		chow.get_ItemTotal();
		//chow.verifyTotalValue();
		float f1=chow.get_ItemTotal();
		System.out.println(f1);
		float f2=chow.get_ItemTax();
		System.out.println(f2);
		float f3=chow.get_Total();
		System.out.println(f3);
		float sum=f1+f2;
		System.out.println("Total actual value is:"+sum);
		
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(sum, f3);
		sa.assertAll();
		chow.cartbtnfinishClick();
	}

}
