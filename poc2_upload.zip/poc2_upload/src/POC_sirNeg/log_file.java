package POC_sirNeg;

import org.apache.log4j.Logger;

public class log_file {
	public static void log(String a,String b)
	{
		Logger log=Logger.getLogger("devpinoyLogger");
		log.debug("Expected result: "+a+" Actual result: "+b+" Test Result:=Pass");
	}

}
