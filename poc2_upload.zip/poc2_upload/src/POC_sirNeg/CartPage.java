package POC_sirNeg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class CartPage {
	WebDriver dr;
	By cart_item,cart_price;
	String base_xp="//div[@class=\"cart_item\"][";
	excel_rw rw=new excel_rw();
	
	public CartPage(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr,this);
	
	}
	public String cartItemName(int n)
	{
		String name="";
		
		cart_item=By.xpath(base_xp+n+"]//div[@class='inventory_item_name']");
		 name=dr.findElement(cart_item).getText();
		return name;	 
	}
	public String price_product(int n)
	{
		
		cart_price=By.xpath(base_xp+n+"]//div[@class='inventory_item_name']");
		String pprice=dr.findElement(cart_price).getText();
		return pprice;
		 
	}
	//*[@id="cart_contents_container"]/div/div[2]/a[1]
	public void clickCheckout()
	{
		dr.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[2]/a[2]")).click();
	}
	public void clickContinue()
	{
		dr.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[2]/a[1]")).click();
	}
	
	@Test
	public void verifyCartProductTxt()
	{
		String str=dr.findElement(By.xpath("")).getText();
		if(str.equals("Products"))
		System.out.println("cartpage opened");
		else
			System.out.println("try again");
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(str, "//*[@id=\"contents_wrapper\"]/div[2]");
		sa.assertAll();
		
	}
	
}
