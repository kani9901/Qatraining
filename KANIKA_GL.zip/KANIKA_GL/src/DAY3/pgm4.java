package DAY3;

public class pgm4 {
	static int max(int arr[],int n)
	{
		int max=arr[0];
		for(int i=0;i<n;i++)
		{
			if(max<arr[i])
				max=arr[i];
		}
		return max;
	}

	public static void main(String[] args) {
		
		int marks[][]= {{77,95,83},{65,92,79}};
		
		for(int i=0;i<=3;i++)
		{
			for(int j=0;j<=4;j++)
			{
				System.out.print(marks[i][j]+" ");
			}
			System.out.println();
		}
		for(int i=0;i<3;i++)
		{
			int maximum=max(marks[i],4);
		System.out.println("max value is "+i+" "+maximum);
		}
		
	}

}
