package DAY3;

public class College {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student Rakesh=new Student();
		
		Rakesh.rollno=73;
		Rakesh.name="Rakesh";
		Rakesh.m1=83;
		Rakesh.m2=91;
		Rakesh.average();
		
		System.out.println(Rakesh.avg);
		
		Student priya=new Student();
		priya.rollno=53;
		priya.name="Rakesh";
		priya.m1=86;
		priya.m2=99;
		priya.average();
		System.out.println(priya.avg);

	}

}
