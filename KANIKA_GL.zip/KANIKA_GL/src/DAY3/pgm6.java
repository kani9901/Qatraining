package DAY3;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Noida",s2="Noida", s3="noida",s4="I am learning java";
		
		int l;
		l=s4.indexOf("a");
		System.out.println(l);
		
		l=s4.indexOf("z",3);
		System.out.println(l);

	}

}
