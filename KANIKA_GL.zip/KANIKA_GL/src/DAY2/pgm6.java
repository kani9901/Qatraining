package DAY2;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=3;i<=30;i++)
		{
			
				if(i%5!=0 && i%3==0)
					System.out.print(" "+i);
			
		}

	}

}
