package DAY2;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=15,sum=0;
		while(n<76)
		{
			
				if(n%7==0)
					sum=sum+n;
				 n++;	
		}
		
		System.out.print(" "+sum);
		
	}

}
