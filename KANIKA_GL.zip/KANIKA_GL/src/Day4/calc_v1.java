package Day4;

public class calc_v1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
