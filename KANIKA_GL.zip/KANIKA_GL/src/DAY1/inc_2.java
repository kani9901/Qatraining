package DAY1;

public class inc_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(10*10/5+3-1*4/2);
	}

}
