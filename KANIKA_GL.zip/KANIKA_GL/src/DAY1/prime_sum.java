package DAY1;

public class prime_sum {
	static boolean isPrime(int n)
	{
		boolean b=true;
		for(int i=2;i<=n/2;i++)
		{
			if(n%i==0)
			{
				b=false;
				return b;
			}
		}
		return b;
	}

	public static void main(String[] args) {
		int  j=0;
		int sum=0;
		int i=2;
		while(true)
		{
			if(j>=10)
				break;
			if(isPrime(i))
			{
				System.out.println(i+" ");
				sum=sum+i;
				j++;
			}
			i++;
		}
		System.out.println("sum= "+sum);
	}
	}
		
