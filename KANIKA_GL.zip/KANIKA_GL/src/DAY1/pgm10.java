package DAY1;

import java.util.Scanner;

public class pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter vowel");
		char s=sc.next().charAt(0);
		
		if(s=='a'||s=='e'||s=='i'||s=='o'||s=='u')
			System.out.println("char is vowel");
		else
			System.out.println("consonant");
	}

}
