package DAY1;

public class pgm9 {
	public static void main(String[] args) 
	{
		int a=10,b=30;
		if(a>b)
			System.out.println("a is greater");
		else if(a==b)
		System.out.println("a is equal to b");
		else
		System.out.println("b is greater");
	}
}
