package DAY1;
import java.util.*;

public class palindrome_number {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number:");
		
		int num= sc.nextInt();
		int sum= 0, rem, OI;
        OI = num;
         
        while( num != 0 )
        {
            rem = num % 10;
            sum= sum * 10 + rem;
            num  /= 10;
        }
        
        if (OI == sum)
            System.out.println(OI + " is a palindrome.");
        else
            System.out.println(OI + " is not a palindrome.");
	}

}
