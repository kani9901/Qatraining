package DAY1;

import java.util.Scanner;

public class pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER MARKS OF I Subject: ");
		float a=sc.nextInt();
		
		System.out.println("ENTER MARKS OF II Subject: ");
		float b=sc.nextInt();
		
		System.out.println("ENTER MARKS OF III Subject: ");
		float c=sc.nextInt();
		
		float sum=0;
		double avg=0;
		
	sum=a+b+c;
	avg=sum/3;
	
	System.out.println("Avg marks is:"+avg);
	if(avg>=60)
		System.out.println("I div");
	if(avg>=50 && avg<60)
		System.out.println("II div");
	if(avg>=35 && avg<50)
		System.out.println("pass");
	if(avg<35)
		System.out.println("fail");
		
	}

}
