package DAY1;

import java.util.Scanner;

public class pgm11 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a:");
		int a=sc.nextInt();
		System.out.println("Enter b:");
		int b=sc.nextInt();
		System.out.println("Enter c:");
		int c=sc.nextInt();
		
		if(a>b&&a>c)
			System.out.println("a is greater"+a);
		if(b>a&&b>c)
			System.out.println("b is greater"+b);
		if(c>b&&c>a)
			System.out.println("c is greater"+c);
	}

}
