package sday4;

public class checking {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	}

}
