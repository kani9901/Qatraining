package sday4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class excel_io_al {
	
	
	public static login_data get_test_data(int r1) 
	{

		login_data td=new login_data();
	String s=null;
	try {

		File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\selenium.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		
		
			XSSFRow r=sh.getRow(r1);
			XSSFCell c=r.getCell(0);
			td.uid=c.getStringCellValue();

			XSSFCell c1=r.getCell(1);
			td.pwd=c1.getStringCellValue();

			XSSFCell c2=r.getCell(2);
			td.exp_res1=c2.getStringCellValue();

			XSSFCell c3=r.getCell(3);
			td.exp_em1=c3.getStringCellValue();

			XSSFCell c4=r.getCell(4);
			td.exp_em2=c4.getStringCellValue();

		

	} 
		catch (Exception e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	return td;

	}

	public static login_data write_excel(int r, login_data ld2) {
		File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\selenium.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
			XSSFRow row=sh.getRow(r);
			XSSFCell cell=row.createCell(7);
			cell.setCellValue(ld2.act_res1);
			
			if(ld2.act_res1.equals("failure"))
			{
				XSSFCell cell2=row.createCell(5);
				cell2.setCellValue(ld2.act_em1);

				XSSFCell cell3=row.createCell(6);
				cell3.setCellValue(ld2.act_em2);
			}
			
			XSSFCell cell4=row.createCell(8);
			cell4.setCellValue(ld2.test_res);

			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ld2;
	}
}
