package sday7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

public class all_webelement_fns {
	
	WebDriver dr;
	
	all_webelement_fns(WebDriver dr)
	{
		this.dr=dr;
	}
	public void enter_txt(String xp,String data)
	{
		System.out.println(xp+" "+data);
		dr.findElement(By.xpath(xp)).sendKeys(data);
		
	}
	public void click(String xp)
	{
		dr.findElement(By.xpath(xp)).click();
	}
	public void launchChrome(String url)
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr=new ChromeDriver();
		dr.get(url);
	}
	public void Click_rb(String xp)
	{
		dr.findElement(By.xpath(xp)).click();
	}
	
	public void verify(String loc,String td,int r)
	{
		System.out.println(td);
		excel_operations eo=new excel_operations();
		String data=dr.findElement(By.xpath(loc)).getText();
		
		//SoftAssert sa=new SoftAssert();
		//sa.assertEquals(data,td);
		//sa.assertAll();
		
		if(data.equals(td))
		{
			eo.write_excel(r, 6, "pass");
			System.out.println("pass");
		}
		else
		{
			eo.write_excel(r, 6, "fail");
			System.out.println("fail");
		}
		
	}
	public void closebrowser()
	{
		dr.close();
	}



}
