package sday7;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class basic_testlogin extends excel_io_arr {
	
	 public static String login(String uid,String pwd, String e_r) 
	 {
		  String a_result;
		  System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		  WebDriver dr = new ChromeDriver();
		   dr.get("http://demowebshop.tricentis.com/login");
		   dr.findElement(By.xpath("//input[@class='email']")).sendKeys(uid);
		   dr.findElement(By.xpath("//input[@class='password']")).sendKeys(pwd);
		   dr.findElement(By.xpath("//input[@value='Log in']")).click(); 

	 boolean f = dr.getTitle().contains("Login");
	 
	 if(!f) {
	 a_result = "SUCCESS";
	  System.out.println("Login Success"); 
	  dr.findElement(By.xpath("//a[@href='/logout']")).click(); 
	 }
	
	else
		{
		a_result = "FAILURE";
		}
		dr.close(); 
		return a_result; 
}
}
