package sday7;

import org.openqa.selenium.WebDriver;

public class driver_script {
	
	public static void main(String args[])
	{
		String kw,loc,td=null;
		WebDriver dr=null;
		all_webelement_fns we= new all_webelement_fns(dr);
		excel_operations excel= new excel_operations();
		
		for(int r=1;r<17;r++)
		{
			kw=excel.read_excel(r,3);
			loc=excel.read_excel(r,4);
			td=excel.read_excel(r,5);
			
			switch(kw)
			{
			case "launchchrome" :
				we.launchChrome(td);
				break;
			case "enter_txt" :
				we.enter_txt(loc,td);
				break;
				
			case "Click_btn" :
				we.click(loc);
				break;
			case"Click_rb":
				we.click(td);
				break;
			case "verify" :
				we.verify(loc,td,r);
				break;
			case "closebrowser" :
				we.closebrowser();
				break;
				
			}
			}
	}

}
