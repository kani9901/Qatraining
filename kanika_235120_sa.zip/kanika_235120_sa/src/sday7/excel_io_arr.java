package sday7;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_io_arr {
		 
		public static String fiLename ="C:\\Users\\kanika.chaudhary\\Documents\\selenium.xlsx"; 
		public static String[][] testdata; 
		public static int rowno,colno;
		
		 public static void get_test_data()
		 {
		 String s = null,s1=null,s2=null; 
		 try 
		 {
			 System.out.println(" in get test data row " + rowno);
			 File f = new File(fiLename); 
		 
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis); 
		XSSFSheet sheet = wb.getSheet("11 nov");
		XSSFRow row = sheet.getRow(rowno);
		XSSFCell cell1 = row.getCell(0); 
		//s = celll.getStringCellValue(); 
		testdata[rowno-1][0] = cell1.getStringCellValue(); 
		
		
		XSSFCell ce112 = row.getCell(1);
		testdata[rowno-1][1] = ce112.getStringCellValue();
		
		XSSFCell ce113 = row.getCell(2); 
		testdata[rowno-1][2] = ce113.getStringCellValue(); 
		 }
		 catch (Exception e) { 
			 System.out.println(e); } 
		

	}

}
