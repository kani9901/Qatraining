package sday7;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


public class dataprovider_login_xl extends basic_testlogin {
	
	@BeforeClass
	public void config()
	{
		testdata =new String[2][3];
		for(rowno=1;rowno<=2;rowno++)
		{
			get_test_data();
		}
	}
	
	 @Test(dataProvider="data")
	  public void login_test1(String u,String p,String exp_res) {
		 String a_res;
		  System.out.println("login: "+u+" "+p+" "+exp_res);
		  
		  a_res=login(u,p,exp_res);
		  
		  SoftAssert sa=new SoftAssert();
		  
		  sa.assertEquals(a_res,exp_res);
		  sa.assertAll();
	  
	  }
	  
	  @DataProvider(name="data")
	  public String[][] getdata() {
		  
		  return testdata;
		
		  
	  }
}
