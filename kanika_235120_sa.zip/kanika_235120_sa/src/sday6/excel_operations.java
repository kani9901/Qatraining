package sday6;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_operations {

	public String read_excel(int r, int i) {
		
		String s1=" ";
		// TODO Auto-generated method stub
		try {
		File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\WebElement.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		
		XSSFRow r1=sh.getRow(r);
		
		XSSFCell c=r1.getCell(i);
		s1=c.getStringCellValue();
		}
		
		catch(Exception e)
		{
			System.out.println(e);
		}
		return s1;
	}

}
