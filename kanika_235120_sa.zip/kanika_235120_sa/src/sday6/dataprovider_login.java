package sday6;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class dataprovider_login {
	
	basic_login loginobj;
	login_data Idata,Idata_out;
	@BeforeClass
	public void config()
	{
		Idata=new login_data();
		Idata_out =new login_data();
		loginobj =new basic_login();
	}
	
  @Test(dataProvider="security")
  public void login_test1(String u,String p,String msg) {
	  System.out.println("login: "+u+" "+p+" "+msg);
	  Idata.uid=u;
	  Idata.pwd=p;
	  Idata.exp_res1=msg;
	  
	  Idata_out=loginobj.login(Idata);
	  SoftAssert sa=new SoftAssert();
	  
	  sa.assertEquals(Idata_out.act_res1,Idata_out.exp_res1);
	  sa.assertAll();
  
  }
  
  @DataProvider(name="security")
  public String[][] getdata() {
	  String[][] data= {{"1234567890kanika@gmail.com","pass123$","success"},
	  					{"1234567890kanika@gmail.com","pass123","fail"}
	  					};  
	  return data;
	
	  
  }
  
}
