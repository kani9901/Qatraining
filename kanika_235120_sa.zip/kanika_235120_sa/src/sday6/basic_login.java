package sday6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class basic_login {
	

public static login_data login(login_data Ldata) {
	// TODO Auto-generated method stub
	System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com/login");
	
	dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(Ldata.uid);
	dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(Ldata.pwd);
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	
	boolean f=dr.getTitle().contains("Login");
	
	if(!f)
	{
		Ldata.act_res1="success";
		System.out.println("login success");
	}
	else {
		Ldata.act_res1="failure";
		Ldata.act_em1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
		Ldata.act_em2=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
	}
	dr.close();
	return Ldata;
}
  
}
