package sday6;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class dataprovider1 {
	
  @Test(dataProvider="security")
  public void login(String u,String p,String er) {
	  System.out.println("Login: "+u+" "+p+" "+er);
  }
  
  @DataProvider(name="security")
  public String[][] getdata() {
	  String[][] data= {{"uid1","pwd1","er1"},
			  			{"uid2","pwd2","er2"}  
	  					};  
	  return data;
	
	  
  }
}
