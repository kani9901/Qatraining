package sday6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test_login {
	
	public static login_data login(login_data Ldata)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(Ldata.uid);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(Ldata.pwd);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		boolean f=dr.getTitle().contains("Login");
		
		if(!f)
		{
			Ldata.act_res1="success";
			System.out.println("login success");
		}
		else {
			Ldata.act_res1="failure";
			Ldata.act_em1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
			Ldata.act_em2=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
		}
		
		if(Ldata.exp_res1.equals("failure"))
		{
			System.out.println("Ldata.exp_em1:"+ Ldata.exp_em1 + "\n Ldata.act_em1: "
		+ Ldata.act_em1 +"Ldata_exp_em2: "+Ldata.exp_em2 + "Ldata.act_em2: "+Ldata.act_em2); 
			
			if(Ldata.exp_em1.equals(Ldata.act_em1) && Ldata.exp_em2.equals(Ldata.act_em2))
			{
				Ldata.test_res="Pass";	
			}
			else
			{
				Ldata.test_res="fail";
			}
			
		}
		else
		{
			Ldata.test_res="Pass";
			//write own
			Ldata.act_res1="success";
			//for logout
			dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
			try
			{
				Thread.sleep(3000);
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			dr.close();
		}
		return Ldata;
	}
	
	
	
}
