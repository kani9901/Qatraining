package sday6;

import org.testng.annotations.Test;

public class NewTest {
	
	@Test(priority=0)
	  public void c() {
				  System.out.println("in test c");
	  }
	  
	  @Test(priority=3)
	  public void b() {
		  System.out.println("in test b");
		  
	  }

	  @Test(priority=5)
	  public void a() {
		  System.out.println("in test a");
	  }
}
