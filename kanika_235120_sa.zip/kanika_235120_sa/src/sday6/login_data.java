package sday6;

public class login_data {

	public String uid,pwd,exp_res1,act_res1,test_res;
	public String exp_em1,exp_em2,act_em1,act_em2;
	
	public login_data(String uid,String pwd,String exp_res,String act_res,String test_res)
	{
		this.uid=uid;
		this.pwd=pwd;
		this.exp_res1=exp_res;
		this.act_res1=act_res;
		this.test_res=test_res;
	}
	
	public login_data()
	{
		
	}
	
	public void display()
	{
		System.out.println("UID      : "+ this.uid
				+"\n PWD	  	     : "+ this.pwd 
				+"\n EXP_RES         : "+ this.exp_res1
				+"\n ACT_RES	     : "+this.act_res1
				+"\n TEST RESULT     : "+this.test_res
				+"\n EXPECTED MSG    : "+this.exp_em1
				+"\n EXPECTED MSG    : "+this.exp_em2
				+"\n ACTUAL MSG 	 : "+this.act_em1
				+"\n ACTUAL MSG 	 : "+this.act_em2
				+"\n ================================");
	}
}
