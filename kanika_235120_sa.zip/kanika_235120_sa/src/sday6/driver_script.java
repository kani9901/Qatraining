package sday6;

import org.openqa.selenium.WebDriver;

public class driver_script {
	
	public static void main(String args[])
	{
		String kw,loc,td;
		WebDriver dr=null;
		all_webelement_fns we= new all_webelement_fns(dr);
		excel_operations excel= new excel_operations();
		
		for(int r=1;r<=11;r++)
		{
			kw=excel.read_excel(r,3);//radio btn
			loc=excel.read_excel(r,4);//xpath
			td=excel.read_excel(r,5);//female
			
			switch(kw)
			{
			case "launchchrome" :
				we.launchChrome(td);
				break;
			case "enter_txt" :
				we.enter_txt(loc,td);
				break;
				
			case "Click_btn" :
				we.click(loc);
				break;
				
		
			}
			}
		dr.close();
	}

}
