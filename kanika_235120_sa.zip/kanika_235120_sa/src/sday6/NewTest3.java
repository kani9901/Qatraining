package sday6;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest3 {
	
	login_data d1,d2;
	test_login l;
	
  @Test
  public void t1() {
	  
	  d1=new login_data();
	  d2=new login_data();
	  l=new test_login();
	  
	  d1.uid="1234567890kanika@gmail.com";
	  d1.pwd="pass123$";
	  d1.exp_res1="pass";
	  
	  d2=test_login.login(d1);
	 System.out.println("Actual result : "+d2.act_res1);
	  
	  
  }
  @Test
  public void t2() {
	  
	  d1=new login_data();
	  d2=new login_data();
	  l=new test_login();
	  
	  d1.uid="1234567890kanika@gmail.com";
	  d1.pwd="pass123";
	  d1.exp_res1="pass";
	  d1.exp_em1="The credentials provided are incorrect";
	  d1.exp_em2="Login was unsuccessful. Please correct the errors and try again.";
	  
	  d2= test_login.login(d1);
	  
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(d2.act_res1, d2.exp_res1);
	  sa.assertAll();
	  
	 System.out.println("Actual result : "+d2.act_res1);
	  
	  
  }
  
}

