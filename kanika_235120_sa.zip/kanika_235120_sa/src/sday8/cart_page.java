package sday8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
//POM
public class cart_page {
	
	WebDriver dr;
	By cart_item;
	String base_xp="//div[@class=\"cart_item\"][";
	
	public cart_page(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr,this);
	
	}
	public String cart(int n)
	{
		/**cart_item=By.xpath("//*[@id=\"item_4_title_link\"]/div");
		String name=dr.findElement(cart_item).getText();
		return name;**/
		
		cart_item=By.xpath(base_xp+n+"]//div[@class='inventory_item_name']");
		String name=dr.findElement(cart_item).getText();
		return name;
		 
	}
	public String price_product(int n)
	{
		
		cart_item=By.xpath(base_xp+n+"]//div[@class='inventory_item_name']");
		String pprice=dr.findElement(cart_item).getText();
		return pprice;
		 
	}
}
