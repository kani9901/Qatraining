package sday10;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class excel_operations {

	public String read_excel(int r, int i) {
		
		String s1=" ";
		// TODO Auto-generated method stub
		try {
		File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\selenium.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("11nov-registration");
		
		XSSFRow r1=sh.getRow(r);
		
		XSSFCell c=r1.getCell(i);
		s1=c.getStringCellValue();
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return s1;
	}
	
	public void write_excel(int r,int c,String value)
	{
		try {
		File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\selenium.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("11nov-registration");
		
				XSSFRow r1=sh.getRow(r);
				XSSFCell c1=r1.createCell(c);
				c1.setCellValue(value);
				
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		}
		
		catch(Exception e)
		{
			System.out.println(e);
		}
		//return s;
	}

}
