package sday10;

public class tc_selection  {

	public String flag="";
	public String tcid;
	public int no_steps;
	public String test_data_sh;
	
	for(int i=1;i<=3;i++)
	{
		System.out.println(flag);
		if(flag.equals(Y))
		{
			for(int j=1;j<17;j++)
			{
				
			}
		}
	}
	
}
