package GRID;

public class tc_selection {

	public String flag;
	public String tcid;
	public int no_steps;
	public String test_data_sh;

	
	/**tc_sh_obj =set_sheet(tc_sheet);
	
	XSSFRow rw=tc_sh_obj.getRow(j);
	tcid=rw.getCell(0).getStringCellValue();
	flag=rw.getCell(1).getStringCellValue();
	no_steps=(int)rw.getCell(2).getNumericCellValue();
	test_data_sh=rw.getCell(3).getStringCellValue();**/
	
	
	

}
