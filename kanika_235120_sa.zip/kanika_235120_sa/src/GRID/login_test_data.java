package GRID;

public class login_test_data {

	public String pwd;
	public String uid;

}
