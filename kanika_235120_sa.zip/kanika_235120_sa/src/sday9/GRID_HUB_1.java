package sday9;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class GRID_HUB_1 {
		
		WebDriver dr;
		String autURL,nodeURL;
		
		@Test
		public void setup() throws MalformedURLException
		{
		autURL="https://www.facebook.com";
		nodeURL="http://172.16.70.237:5566/wd/hub";
		DesiredCapabilities cap=DesiredCapabilities.chrome();
		cap.setBrowserName("chrome");
		cap.setPlatform(Platform.WINDOWS);
		
		dr=new RemoteWebDriver(new URL(nodeURL),cap);
		}
		
		
		@Test
		public void test2() throws MalformedURLException
		{
			nodeURL="http://172.16.70.237:5566/wd/hub";
			DesiredCapabilities cap=DesiredCapabilities.chrome();
			cap.setBrowserName("chrome");
			cap.setPlatform(Platform.WINDOWS);
			try
			{
			dr=new RemoteWebDriver(new URL(nodeURL),cap);
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			dr.get("https://www.facebook.com");
			}	
		
		
}
