package sday3;

public class login {

	String email;
	public String pwd;
	public String e_result;
	String a_result;
	String test_result;
	

}
