package sday3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class dropdown {
//leave this program site 
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://ultimateqa.com/simple-html-elements-for-automation/");
		
		//for check box
		//dr.findElement(By.xpath(" //*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[8]/div/div/div/form/input[1]")).click();
		//dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[8]/div/div/div/form/input[2]")).click();
		
		
		//for dropdown
		//dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[10]/ul/li[1]/a")).click();
		dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[10]/ul/li[2]/a")).click();
		
	}

}
