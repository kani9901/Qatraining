package sday3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login_excel {
	login data;
	
	public static login read_excel()
	{
		login testdata =new login();
		try {
		
		
		File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\Book4.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("selenium");
		
		XSSFRow r=sh.getRow(1);
		
		XSSFCell c=r.getCell(0);
		testdata.email=c.getStringCellValue();
		
		XSSFCell c1=r.getCell(1);
		testdata.pwd=c1.getStringCellValue();
		
		XSSFCell c2=r.getCell(2);
		testdata.e_result=c2.getStringCellValue();
		
		
		
		
	}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return testdata;
	}
	
	public static void write_excel(login p2)
	{
		try 
		{
			
		File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\Book4.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("selenium");
		
		XSSFRow r=sh.getRow(1);
		
		XSSFCell c=r.createCell(3);
		c.setCellValue(p2.a_result);
		
		XSSFCell c1=r.createCell(4);
		c1.setCellValue(p2.test_result);

	    FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		}
		
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	
	public static void login(login p1)
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(p1.email);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(p1.pwd);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	
		//String e_result="";
		p1.a_result=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		
		
		if(p1.a_result.equals(p1.e_result))
		{
			p1.test_result="PASS";
			System.out.println("pass");
		}
			else
			{
				p1.test_result="FAIL";
			System.out.println("fail");
			}
	}
	
	public static void main(String args[])
	{
		login p=new login();
		p=read_excel();
		login(p);
		write_excel(p);
	}

}
