package sady2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");//setting property 
	 
	WebDriver dr=new ChromeDriver(); //launching chrome driver
	dr.get("https://www.w3schools.com/html/html_tables.asp");
	
	
	String str=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[1]/th[3]")).getText();
	
	System.out.println(str);
	
	//*[@id="customers"]/tbody/tr[1]/th[3]
	//*[@id="customers"]/tbody/tr[1]/th[3]
	//*[@id="customers"]/tbody/tr[3]/td[3]
	for(int i=2;i<=7;i++)
	{
		for(int j=1;j<=3;j++)
		{
		String xp="//*[@id=\"customers\"]/tbody/tr["+ i + " ]/td["+ j +"]";
		String s=dr.findElement(By.xpath(xp)).getText();
		System.out.println(s+" ");
		}
		System.out.println();
	}
	}
}
