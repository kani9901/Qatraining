package sday1;


import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class wb_day1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");//setting property 
 
		WebDriver dr=new ChromeDriver(); //launching chrome driver
		dr.get("https://www.facebook.com");
		
		//sending text to the particular text button
		//dr.findElement(By.id("email")).sendKeys("kanikachaudhary2606@gmail.com");
		
	dr.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("7217727838");
		dr.findElement(By.xpath("//*[@id=\"pass\"]")).sendKeys("Kanika@123");
		
		//dr.findElement(By.xpath("//*[@id=\"u_0_b\"]")).click();
		dr.findElement(By.xpath("//*[@id='loginbutton']")).click();
		
	
		//for drop down values
	/**	WebElement we1=dr.findElement(By.xpath("//*[@id=\"day\"]"));
		Select sel1=new Select(we1);
		sel1.selectByVisibleText("10");
		
		WebElement we2=dr.findElement(By.xpath("//*[@id=\"month\"]"));
		Select sel2=new Select(we2);
		sel2.selectByVisibleText("Jun");**/
		
		//for title printing
		String title=dr.getTitle();
		System.out.println(title);
		
		
		//for radio btn
		//List rb=dr.findElements(By.name("sex"));
		//((WebElement)rb.get(0)).click();
		
		//for profile name after login
		String a_profilename=dr.findElement(By.xpath("//*[@id=\"navItem_100042825050714\"]/a/div")).getText();
		//*[@id="u_0_a"]/div[1]/div[1]/div/a/span/span
		//String e_profilename="kanika";
		
		//to check whether its login is suceessful or not
		if(a_profilename.equals("Kanika Chaudhary"))
		System.out.println("login successful");
		else
			System.out.println("not successful");
		
		
		
	}

}
