package cum_step_def;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test2 {
	
	WebDriver dr;
	
	@When("^user enters invalid details$")
	public void user_enters_invalid_details() throws Throwable {
		
		dr=test1.dr;
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("kanika.chaudhary@globallogic.com");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("kanika@0001");//invalid data
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		System.out.println("user enters invalid details");       
	}

	@Then("^login is not successful$")
	public void login_is_not_successful() throws Throwable {
	   
		  String email= dr.findElement(By.xpath("//div[@class='header-links']/ul/li[1]")).getText();
		  String str="kanika.chaudhary3424@globallogic.com";
		  SoftAssert sa=new SoftAssert();
		  sa.assertEquals(email,str);
		  System.out.println("login is not successful");
		  sa.assertAll();
	}

}

