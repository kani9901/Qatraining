package ASSIGNMENT;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Registration {
	
	WebDriver dr;
	public String register(String fname,String lname,String email,String pass,String cpass) {
	 System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		
		//for clicking on registration
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
		
		//for printing title
		String title=dr.getTitle();
		System.out.println(title);
		
			boolean f=dr.getTitle().contains("Register");
			
			if(!f)
			{System.out.println("try again:");}
			else
			{
				System.out.println("Registration page open");
			}
			
	 System.out.println("Registration:"+fname+" "+lname+" "+email+" "+pass+" "+cpass);
	  dr.findElement(By.xpath("//*[@id=\"gender-female\"]")).click();
	  dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(fname);
	  dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(lname);
	  dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(email);
	  
	  dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(pass);
	  dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(cpass);
	  dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
	  
	  
	 String str= dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	 
	//logout
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		
	return str;
	
  }
  
  @DataProvider(name="security")
  public String[][] provide_data() {
	  String[][] data= {{"email","id","emailid11@gmail.com","emailid1","emailid1"},//valid for new registration
			  			{"email1","id1","emailid9@gmail.com","emailid2","emailid2"}//already register
	  				   };  
	return data;
	  
  }
  
  @Test(dataProvider="security")
  public void Test1(String fname,String lname,String email,String pass,String cpass)
  {
	  String str1=register(fname,lname,email,pass,cpass);
	  
	  if(str1.equals(email))
			System.out.println("Expected result:\n "+email+" "+"Actual result"+str1);
		else
			System.out.println("register fail");
	  
	  SoftAssert sa=new SoftAssert();
		sa.assertEquals(str1, email);
		System.out.println("registration successful");
		sa.assertAll();
  }

}
