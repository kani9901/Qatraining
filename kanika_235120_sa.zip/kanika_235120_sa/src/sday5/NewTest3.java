package sday5;

import org.testng.annotations.Test;

public class NewTest3 {
	
	login_data d1,d2;
	test_login l;
	
  @Test
  public void t1() {
	  
	  d1=new login_data();
	  d2=new login_data();
	  l=new test_login();
	  
	  d1.uid="1234567890kanika@gmail.com";
	  d1.pwd="pass123$";
	  d1.exp_res1="pass";
	  
	  d2=test_login.login(d1);
	 System.out.println("Actual result : "+d2.act_res1);
	  
	  
  }
  @Test
  public void t2() {
	  
	  d1=new login_data();
	  d2=new login_data();
	  l=new test_login();
	  
	  d1.uid="1234567890kanika@gmail.com";
	  d1.pwd="pass123";
	  d1.exp_res1="pass";
	  
	  d2=l.login(d1);
	 System.out.println("Actual result : "+d2.act_res1);
	  
	  
  }
  
}

