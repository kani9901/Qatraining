package sday5;

import org.testng.annotations.Test;
import sday4.login_data;
import sday4.test_login;

public class NewTest1 {
	
	test_login loginobj;
	login_data ldata,ldata_out;
	
  @Test
  public void t1() {
	  ldata =new login_data();
	  ldata_out=new login_data();
	  loginobj =new test_login();
	  
	  ldata.uid="trainingservices07@gmail.com";
	  ldata.pwd="password";
	  ldata.exp_res1="success";
	  
	  ldata_out=test_login.login(ldata);
	  System.out.println("ldata_out.act_res1: "+ ldata_out.act_res1);
	  
  }
  @Test
  public void t2() {
	  ldata =new login_data();
	  ldata_out=new login_data();
	  
  }
}
