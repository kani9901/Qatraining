package sday5;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest {
  @Test
  public void t1() {
	  System.out.println("in test f");
  }
  //it does not run because it does not have(@Test)
  public void t2() {
	  System.out.println("in test f");
  }
  @Test
  public void t3() {
	  System.out.println("in test f");
  }
  @AfterMethod
  public void AM()
  {
	  System.out.println("AM");
  }
  @BeforeMethod
  public void BM()
  {
	  System.out.println("BM");
  }
}

