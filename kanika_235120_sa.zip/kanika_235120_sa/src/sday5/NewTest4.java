package sday5;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest4 {
	
	@BeforeClass
	  public void BC() {
		System.out.println("I came to the cricket stadium");
	  }
	@AfterClass
	  public void AC() {
		System.out.println("Now i am back home");
	  }
	@BeforeMethod
	  public void BM() {
		System.out.println("hello");
	  }
	@AfterMethod
	  public void AM() {
		System.out.println("bye");
	  }
	@Test
	  public void t1() {
		System.out.println("I met Mr. dhoni");
	  }
	@Test
	  public void t2() {
		System.out.println("I had my lunch with with kohli");
	  }
	@Test
	  public void t3() {
		System.out.println("I took pic with rohit sharma");
	  }
}
