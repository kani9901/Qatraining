package package1;

import org.testng.annotations.Test;

public class Test1 {
	
  @Test
  public void f() {
	  System.out.println("maven_3 png1 test_1");
  }
  
}
