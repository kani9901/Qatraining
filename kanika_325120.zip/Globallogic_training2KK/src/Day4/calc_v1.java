package Day4;

public class calc_v1 {

	
		// TODO Auto-generated method stub
		public int add(int x,int y)
		{
			int z=x+y;
			return z;
		}
		public float add(int x,int y,float z)
		{
			float f=x+y+z;
			return f;
		}
		public float add(float x,float y)
		{
			return 1.0f;
		}
		public float add(float x,int y)
		{
			return 1;
		}
		public float add(int x,float y)
		{
			return 2;
		}
		
		

	}


