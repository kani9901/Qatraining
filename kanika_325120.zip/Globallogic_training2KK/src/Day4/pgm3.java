package Day4;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 String live="I am working with global logic in noida";
		       
		 String arr[]=new String[8];
		int index1=0,index2,j=0;
	       for(int i=0;i<=live.length()-1;i++)
	       {
	    	   if(live.charAt(i)==' ')
	    		  
	    	   {
	    		   index2=i;
	    		   arr[j]=live.substring(index1,index2);
	    		   index1=index2+1;
	    		   j++;
	    	   }
	    	   
	       }
	 arr[j]=live.substring(index1,live.length());
	        for (int i=0;i<=j;i++) 
	            System.out.println(arr[i]); 
		    } 

}
