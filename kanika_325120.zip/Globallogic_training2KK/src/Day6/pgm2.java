package Day6;

import java.util.ArrayList;

public class pgm2 {
	public static void main(String[] args) {
		ArrayList<String> str_s1=new ArrayList<String>();
		
		str_s1.add("kanika");
		str_s1.add("kani");
		str_s1.add("kannu");
		str_s1.add("kannna");
		str_s1.add("kanikaa");

		System.out.println("before insertion"+str_s1);
		str_s1.add(2,"priya");
		System.out.println("after insertion"+str_s1);
		str_s1.remove("kanika");
		System.out.println("After del"+str_s1);
		
		
		
	}
	}

