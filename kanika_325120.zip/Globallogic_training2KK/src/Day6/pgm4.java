package Day6;
//Tiger and Elephant
public class pgm4
{
	

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Elephant e1 = new Elephant(7,6);
		Elephant e2 = new Elephant(6,5);
		Tiger t1 = new Tiger(6,7);
		Tiger t2 = new Tiger(7,9);
		
		e1.age=30;
		e1.gender="Female";
		e1.name=" Rani ";
		e1.nol=4;
		e1.display();
		//System.out.println();
		e1.eats();
		//System.out.println();
		e1.swim();
		//System.out.println();
		
		
		e2.age=31;	
		e2.gender="Female";
		e2.name="Mahima ";
		e2.nol=4;
		e2.display();
		System.out.println();
		e2.runs();
		System.out.println();
		e2.swim();
	
		t1.age=32;
		t1.gender="male";
		t1.name="Tiger1 ";
		t1.display();
		t1.climb();
		t1.eats();
		t1.roar();
		
		t2.age=33;
		t2.gender="male";
		t2.name="Tiger2 ";
		t1.display();
		t2.climb();
		t2.roar();
		t2.runs();
		

}
	
}
