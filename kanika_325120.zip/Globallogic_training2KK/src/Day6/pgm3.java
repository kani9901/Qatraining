package Day6;

import java.util.ArrayList;


public class pgm3
	
	{
	ArrayList<Student> std_al=new ArrayList<Student>();
	public void create_a1()
	{
		Student s1=new Student("Ramesh",101,80,90);
		Student s2=new Student("Suresh",101,80,90);
		std_al.add(s1);
		std_al.add(s2);
		
	}
	
	public void display_a1()
	{
		for(Student s : std_al )
		{
			System.out.println("Name :"+ s.name +
					"Rollno :" +s.rollno+
					"Sel marks"+s.sel+
					"java marks"+s.jav+
					"avg"+s.avg);
			}
		}
				
				public static  void main(String a[])
						{
					pgm3 a1=new pgm3();
					a1.create_a1();
					System.out.println("Output of display");
					a1.display_a1();
					System.out.println("Output of display");
						}
					
		}
	

