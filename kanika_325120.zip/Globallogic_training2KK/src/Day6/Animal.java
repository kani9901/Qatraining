package Day6;

public class Animal {
	
	int nol;
	String name;
	String gender;
	int age;
	
	
	public void walks() {
		System.out.println("the animal walks\n");
	}
	
	public void eats() {
		System.out.println("the animal eats\n");
	}
	
	public void runs() {
		System.out.println("the animal runs\n");
	}
	
	public void display() {
		System.out.println(" No of legs: " +this.nol +" Name: "+this.name 
							+ " Gender: " + this.gender + " Age: " + this.age );
	}
	
}
