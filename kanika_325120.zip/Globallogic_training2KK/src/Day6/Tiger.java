package Day6;

public class Tiger extends Animal{
	int leghtofteath;
	int lenghtofclaw;
	
	public void roar() {
		System.out.println("Tiger Roars");
	}
	

	public void climb() {
		System.out.println("Tiger climbs tree");
	}
	
	public Tiger(int lott, int loc) {
		// TODO Auto-generated constructor stub
		this.leghtofteath=lott;
		this.lenghtofclaw=loc;
	}


	public void display() {
		System.out.println(  " Name: "+this.name 
							+ " Gender: " + this.gender + " Age: " + this.age );
		
	
	}

}
