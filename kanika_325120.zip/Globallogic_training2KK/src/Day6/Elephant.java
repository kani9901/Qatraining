package Day6;

public class Elephant extends Animal{
	int lot;
	int lotusks;
	
	public void swim() {
		System.out.println("Elephant swims");
	}
	
	public Elephant(int lot, int lotusks)
	{
		// TODO Auto-generated constructor stub
		this.lot=lot;
		this.lotusks=lotusks;
	}


	public void display() {
		System.out.println(" Name: "+this.name  +this.nol +  " Gender: " + this.gender + " Age: " + this.age );
		
		
	}
}
