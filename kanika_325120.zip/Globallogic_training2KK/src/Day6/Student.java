package Day6;

public class Student {

	public String name;
    	public	int rollno;
    	 public int sel;
    	public	float avg;
	    public int jav;
	 
	public void average()
	{
		  this.avg=((jav+sel)/2);
	}
	 
	   public Student(String name, int rollno, int sel, int jav) {
			// TODO Auto-generated constructor stub
		   this.name=name;
			this.rollno= rollno;
			this.sel=sel;
			this.jav=jav;
			this.average();
		}
	}

