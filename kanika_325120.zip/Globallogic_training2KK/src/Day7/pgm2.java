package Day7;

import java.util.ArrayList;

public class pgm2 {

	public static void main(String[] args) {
		pgm1 excel=new pgm1();
		
		ArrayList<Student> s1=excel.read_excel();
		excel.write_excel(s1);
	
	}

}
