package Day7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class pgm1 {

		public ArrayList<Student> read_excel(){

			ArrayList<Student> std_a1=new ArrayList<Student>();
			
		for(int i=1;i<=3;i++)
		{
			try
			{
				Student s=new Student();
				File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\Book3.xlsx");
				FileInputStream fis = new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				
				XSSFRow r=sh.getRow(i);
				
				XSSFCell c1=r.getCell(0);
				s.rollno=(int) c1.getNumericCellValue();
			
				XSSFCell c2=r.getCell(1);
				s.name= c2.getStringCellValue();
				
				XSSFCell c3=r.getCell(2);
				s.marks_java=(int) c3.getNumericCellValue();
				
				XSSFCell c4=r.getCell(3);
				s.marks_sel=(int) c4.getNumericCellValue();
				//System.out.println(s);
				
				s.average();
			 std_a1.add(s);
				
		
			} 
			catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			}
		}
		return std_a1;
			

	}

		public void write_excel(ArrayList<Student> s1)
		{
			
				try {
						File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\Book3.xlsx");
						FileInputStream fis = new FileInputStream(f);
						XSSFWorkbook wb=new XSSFWorkbook(fis);
						XSSFSheet sh=wb.getSheet("Sheet1");
						int row=1;
						for(Student s: s1)
						{
						XSSFRow r=sh.getRow(row);
						XSSFCell c=r.createCell(4);
						
					c.setCellValue((double) s.avg);
					row++;
						}
					FileOutputStream fos=new FileOutputStream(f);
					wb.write(fos);
						
					} 
					catch (Exception e) {
						// TODO Auto-generated catch block
						System.out.println(e);
					}
					
}
}
