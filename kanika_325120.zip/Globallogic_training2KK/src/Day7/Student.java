package Day7;

public class Student {
	
	int avg=0;
	public int rollno;
	public String name;
	public int marks_java;
	public int marks_sel;
	
	
	public void average() {
		this.avg=(this.marks_java+this.marks_sel)/2;
	}
}
