package DAY5;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			int num[]= {1,2,3};
			int b= num[3];
					System.out.println(b);
		int m=10,n=0,z;
		z=m/n;
		System.out.println(z);
		}
		catch(ArithmeticException e)
		{
			System.out.println("can not divide by 0:");
		}
		catch(ArrayIndexOutOfBoundsException ae)
		{
			System.out.println("can not divide by 0:");
		}
		catch(Exception e)
		{
			System.out.println("can not divide by 0:");
		}
		System.out.println("OO catch block");

	}

}
