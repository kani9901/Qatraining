package DAY5;

import java.io.*;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\Book1.xlsx");
		
		try {
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			
			XSSFSheet sh=wb.getSheet("Sheet1");
			//XSSFRow r=sh.getRow(2);
			//XSSFCell c=r.getCell(0);
			
			XSSFRow r=sh.getRow(3);
			XSSFCell c=r.getCell(0);
			
			String s=c.getStringCellValue();
			System.out.println(s);
			
			c.setCellValue("Selenium");
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			
		//	wb.close();
			
		} 
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
