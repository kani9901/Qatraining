package DAY5;

import DAY3.Student;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//int r1=1;
		pgm3 excel= new pgm3();
		
		for(int i=0;i<2;i++)
		{
			
		
		Student s1=excel.read_excel(i);
		
		System.out.println(s1.marks_java);
		s1.average();
		System.out.println(s1.avg);
		excel.write_excel(s1,i);
	}
	}
	

}
