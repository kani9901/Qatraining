package Weekend;

public class pgm1 {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int n=0;
		int a1[]=new int[20];
		int a2[]=new int[20];
		int result[]=new int[20];
		int length = 20;
		int j=0;
		System.out.print("a1 ");
		for(int i=10;i<=30;i++) {
		if(i%3==0)
		{
			a1[j]=i;
			
			System.out.print(+ a1[j]+" ");
			j++;
		}
		
		}
		System.out.println();
		System.out.print("a2 ");
		for(int i=10;i<=30;i++) {
			if(i%5==0)
			{
				a2[j]=i;
				
				System.out.print(+a2[j]+" ");
				j++;
			}
			
			}
		System.out.println();
		System.out.println("sum is:");
		
		for (int i = 0; i < length; ++i) {
		    result[i] = a1[i] + a2[i];
		    System.out.print(result[i]+" ");

		}}
}
