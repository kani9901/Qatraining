package Weekend2;

public class pgm2 {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			int arr[] = new int[5];
			int num,rem,l=1000, sum = 0;
			int c=0;
			
			for (int i = 2; i <= l; i++)
			{
				num = i;
				while (num > 0)
				{
					rem = num % 10;
					sum = sum + (rem*rem*rem);
					num = num / 10;
				}
		 
				if (sum == i)
				{
					arr[c]=i;
					c++;
				}
				sum = 0;
				
			}
			for(int i=0;i<5;i++) {
				System.out.println(arr[i]);
			}
			

		

	}


}
