package Day8;

import java.util.ArrayList;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pgm1 excel=new pgm1();
		
		ArrayList<Passenger> s1=excel.read_excel();
		excel.write_excel(s1);
		

	}

}