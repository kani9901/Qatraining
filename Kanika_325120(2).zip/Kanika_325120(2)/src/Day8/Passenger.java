package Day8;

public class Passenger {

	int cost;
	int Rate;
	int Seat;
	public int sno;
	public String Pname;
	public String From;
	public String To;
	public float Total_cost()
	{
		this.cost=(Rate*Seat);
		return cost;
	}
}
