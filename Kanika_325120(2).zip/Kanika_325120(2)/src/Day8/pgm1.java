package Day8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Day7.Student;

public class pgm1 {

	public ArrayList<Passenger> read_excel()
	{
		ArrayList<Passenger> std_a1=new ArrayList<Passenger>();
		for(int i=1;i<=4;i++)
		{
			try {
			Passenger p=new Passenger();
			File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\Book3.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet2");
			
			XSSFRow r=sh.getRow(i);
			
			XSSFCell c1=r.getCell(0);
			p.sno=(int) c1.getNumericCellValue();
		
			XSSFCell c2=r.getCell(1);
			p.Pname= c2.getStringCellValue();
			
			XSSFCell c3=r.getCell(2);
			p.From= c3.getStringCellValue();
			
			XSSFCell c4=r.getCell(3);
			p.To=c4.getStringCellValue();
			
			XSSFCell c5=r.getCell(4);
			p.Rate=(int) c5.getNumericCellValue();
			
			XSSFCell c6=r.getCell(5);
			p.Seat=(int) c6.getNumericCellValue();
			//System.out.println(p);
			
			
			p.Total_cost();
			System.out.println(p.Total_cost());
		 std_a1.add(p);
			
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
		return std_a1;
		
	}
	public void write_excel(ArrayList<Passenger> s1)
	{
		
			try {
					File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\Book3.xlsx");
					FileInputStream fis = new FileInputStream(f);
					XSSFWorkbook wb=new XSSFWorkbook(fis);
					XSSFSheet sh=wb.getSheet("Sheet2");
					
					int row=1;
					
					for(Passenger s: s1)
					{
					XSSFRow r=sh.getRow(row);
					XSSFCell c=r.createCell(6);
					
				c.setCellValue((double) s.cost);
				row++;
					}
				FileOutputStream fos=new FileOutputStream(f);
				wb.write(fos);
			//	System.out.println("ftfdtrfc");
					
				} 
				catch (Exception e) {
					// TODO Auto-generated catch block
					System.out.println(e);
				}
				
}

}
