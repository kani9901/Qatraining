package Day10;

public class table1 {
	int route_id;
	String from,to;
	int unit_price;
	

}
