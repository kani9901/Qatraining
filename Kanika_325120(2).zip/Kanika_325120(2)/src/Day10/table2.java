package Day10;

public class table2 {

	int c_id;
	
	 String c_name;
	
}
