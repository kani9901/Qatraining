package Day10;

public class Passenger {
	
	public static void main(String args[])
	{
	
		pgm1 t1=new pgm1();
		t1.read_excel1();
	
	
	
}
}