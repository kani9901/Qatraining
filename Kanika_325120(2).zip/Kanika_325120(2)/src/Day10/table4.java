package Day10;

public class table4 {

	int c_id;
	String cname,from,to;
	int unit_price,NOT,price;
	public int priceP()
	{
		this.price=(this.unit_price * this.NOT);
		return price;
	}
}
