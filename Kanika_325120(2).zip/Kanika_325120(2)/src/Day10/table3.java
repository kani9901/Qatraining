package Day10;

public class table3 {

	int c_id;
	int r_id;
	int NOT;
	
}
