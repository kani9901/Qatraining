package Day10;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class pgm1 {

	ArrayList<table1> al_t1;
	ArrayList<table2> al_t2;
	ArrayList<table3> al_t3;
	
	public void read_excel1()
	{
		al_t1=new ArrayList<table1>();
		
		for(int i=2;i<4;i++)
		try {
			
		table1 p=new table1();
		File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\Book3.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet3");
		
		XSSFRow r=sh.getRow(i);
		
		XSSFCell c=r.getCell(0);
		p.route_id=(int)c.getNumericCellValue();
		
		XSSFCell c1=r.getCell(1);
		p.from=c1.getStringCellValue();
		
		XSSFCell c2=r.getCell(2);
		p.to= c2.getStringCellValue();
		
		XSSFCell c3=r.getCell(3);
		p.unit_price=(int) c3.getNumericCellValue();
		
		//System.out.println(R_Id);
		al_t1.add(p);
		
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		//return al_t1;
		System.out.println(al_t1.get(0).route_id+" "+al_t1.get(0).from+" "+al_t1.get(0).to+" "+al_t1.get(0).unit_price);
		System.out.println(al_t1.get(1).route_id+" "+al_t1.get(1).from+" "+al_t1.get(1).to+" "+al_t1.get(1).unit_price);
		
	}
	
	public void read_excel2()
	{
		al_t2=new ArrayList<table2>();
		
		for(int i=2;i<4;i++)
		try {
		table2 p=new table2();
		File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\Book3.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet4");
		
		XSSFRow r=sh.getRow(i);
		
		XSSFCell c=r.getCell(0);
		p.c_id=(int)c.getNumericCellValue();
		
		XSSFCell c1=r.getCell(1);
		p.c_name=c1.getStringCellValue();
		
		
		//System.out.println(R_Id);
		al_t2.add(p);
		
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		//return al_t1;
		
	}
	
	public void read_excel3()
	{
		al_t3=new ArrayList<table3>();
		
		for(int i=2;i<4;i++)
		try {
		table3 p=new table3();
		File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\Book3.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet5");
		
		XSSFRow r=sh.getRow(i);
		
		XSSFCell c=r.getCell(0);
		p.c_id=(int) c.getNumericCellValue();
		
		XSSFCell c1=r.getCell(1);
		p.r_id=(int) c1.getNumericCellValue();
		
		XSSFCell c2=r.getCell(2);
		p.NOT= (int) c2.getNumericCellValue();
		
		
		al_t3.add(p);
		
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	
	}
	public void write_excel(ArrayList<Passenger> pass) {
		try {
		File f=new File("C:\\Users\\kanika.chaudhary\\Documents\\book3.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet6");
		
		
	    int row=2;
	
	
		
		
		
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
	
	}
}
