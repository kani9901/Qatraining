package Day9;

public class hdfc extends bank{
	
	public float get_roi()
	{
		return 9.5f;
	}

}
