package Day9;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pgm2 e=new pgm2();
		
		e.setAccount_no(1001);
		e.setAccount_bal(1000);
		System.out.println("Account Number :"+ e.getAccount_no()+"Account Balance"+e.getAccount_bal());
	}

}
